const PHOTON_BASE = 'https://photon.komoot.io';
const OSRM_BASE = 'https://router.project-osrm.org';

const STREET_SUFFIXES = new Set([
  'st','street','rd','road','dr','drive','ln','lane','ave','avenue','blvd','boulevard','ct','court',
  'cir','circle','trl','trail','pkwy','parkway','pl','place','way','ter','terrace','hwy','highway'
]);

function compactParts(parts) {
  return parts.filter(Boolean).map((part) => String(part).trim()).filter(Boolean);
}

function normalizeText(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function tokenize(value) {
  return normalizeText(value).split(' ').filter(Boolean);
}

function stripStreetSuffixes(tokens = []) {
  return tokens.filter((token) => !STREET_SUFFIXES.has(token));
}

function cityLine(props = {}) {
  return compactParts([
    props.city,
    props.county,
    props.state,
    props.postcode
  ]).join(', ');
}

function streetLine(props = {}) {
  return compactParts([
    props.housenumber,
    props.street,
    props.name && !props.street ? props.name : ''
  ]).join(' ');
}

function mapPhotonFeature(feature, index, origin = null) {
  const props = feature?.properties || {};
  const coords = Array.isArray(feature?.geometry?.coordinates) ? feature.geometry.coordinates : [];
  const lon = Number(coords[0]);
  const lat = Number(coords[1]);
  const primaryLine = streetLine(props) || props.name || props.street || '';
  const secondaryLine = cityLine(props) || compactParts([props.country]).join(', ');
  const label = compactParts([primaryLine, secondaryLine]).join(', ') || props.name || '';
  const distanceFromOriginMiles = origin && Number.isFinite(origin.lat) && Number.isFinite(origin.lon)
    ? haversineMiles(origin, { lat, lon })
    : null;

  return {
    label,
    primaryLine,
    secondaryLine,
    lat,
    lon,
    placeId: props.osm_id || `${lat}|${lon}|${label}`,
    distanceFromOriginMiles,
    raw: feature,
    rankIndex: index,
    normPrimary: normalizeText(primaryLine),
    normSecondary: normalizeText(secondaryLine),
    normRoad: normalizeText(props.street || props.name || ''),
    houseNumber: normalizeText(props.housenumber || ''),
    cityName: normalizeText(props.city || ''),
    type: props.type || ''
  };
}

function distanceScore(miles) {
  if (!Number.isFinite(miles)) return 0;
  if (miles <= 2) return 280;
  if (miles <= 6) return 230;
  if (miles <= 12) return 180;
  if (miles <= 25) return 120;
  if (miles <= 50) return 55;
  if (miles <= 100) return 0;
  if (miles <= 200) return -80;
  return -180;
}

function scoreResult(entry, query) {
  const normalized = normalizeText(query);
  const tokens = tokenize(normalized);
  if (!normalized || !tokens.length) return 0;

  const houseToken = /^\d+[a-z]?$/.test(tokens[0]) ? tokens[0] : '';
  const streetTokens = stripStreetSuffixes(houseToken ? tokens.slice(1) : tokens);
  const primaryTokens = tokenize(entry.normPrimary);
  const roadTokens = stripStreetSuffixes(tokenize(entry.normRoad));
  const haystack = `${entry.normPrimary} ${entry.normSecondary}`.trim();
  const joinedStreet = streetTokens.join(' ');
  const joinedRoad = roadTokens.join(' ');
  const looksLikeStreetAddress = Boolean(houseToken || streetTokens.length >= 1);

  let score = 0;
  if (entry.normPrimary.startsWith(normalized)) score += 320;
  else if (entry.normRoad.startsWith(normalized)) score += 300;
  else if (haystack.startsWith(normalized)) score += 220;
  else if (entry.normRoad.includes(normalized)) score += 180;
  else if (entry.normPrimary.includes(normalized)) score += 150;

  if (houseToken) {
    if (entry.houseNumber === houseToken) score += 260;
    else if (primaryTokens[0] === houseToken) score += 160;
    else score -= 90;
  }

  if (streetTokens.length) {
    if (joinedRoad.startsWith(joinedStreet)) score += 340;
    else if (joinedRoad.includes(joinedStreet)) score += 220;
    else if (entry.normPrimary.includes(joinedStreet)) score += 120;

    let matched = 0;
    streetTokens.forEach((token, idx) => {
      const roadToken = roadTokens[idx] || '';
      if (roadToken === token) {
        matched += 1;
        score += 85;
      } else if (roadToken.startsWith(token) || token.startsWith(roadToken)) {
        matched += 0.75;
        score += 55;
      } else if (roadTokens.includes(token)) {
        matched += 0.5;
        score += 24;
      }
    });
    if (matched >= streetTokens.length) score += 130;
  }

  if (looksLikeStreetAddress && !entry.normRoad) score -= 220;
  if (looksLikeStreetAddress && ['county','state','country','city','district','locality'].includes(String(entry.type))) score -= 120;

  score += distanceScore(entry.distanceFromOriginMiles);
  return score;
}

function rankResults(results, query, origin = null) {
  return [...results].sort((a, b) => {
    const aScore = scoreResult(a, query);
    const bScore = scoreResult(b, query);
    if (aScore !== bScore) return bScore - aScore;

    if (origin) {
      const aDist = Number.isFinite(a.distanceFromOriginMiles) ? a.distanceFromOriginMiles : Number.POSITIVE_INFINITY;
      const bDist = Number.isFinite(b.distanceFromOriginMiles) ? b.distanceFromOriginMiles : Number.POSITIVE_INFINITY;
      if (Math.abs(aDist - bDist) > 0.05) return aDist - bDist;
    }
    return a.rankIndex - b.rankIndex;
  });
}

export function debounce(fn, delay = 250) {
  let timer = 0;
  return (...args) => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => fn(...args), delay);
  };
}

async function fetchPhoton(query, { limit = 10, origin = null } = {}) {
  const url = new URL('/api', PHOTON_BASE);
  url.searchParams.set('q', query);
  url.searchParams.set('limit', String(Math.min(Math.max(limit, 1), 15)));
  if (origin && Number.isFinite(origin.lat) && Number.isFinite(origin.lon)) {
    url.searchParams.set('lat', String(origin.lat));
    url.searchParams.set('lon', String(origin.lon));
    url.searchParams.set('location_bias_scale', '0.85');
  }
  const response = await fetch(url.toString(), {
    headers: { 'Accept': 'application/json' },
    mode: 'cors',
    cache: 'no-store'
  });
  if (!response.ok) {
    throw new Error(`Address lookup failed (${response.status})`);
  }
  const payload = await response.json();
  return Array.isArray(payload?.features) ? payload.features : [];
}

export async function searchAddresses(query, { limit = 5, origin = null } = {}) {
  const text = String(query || '').trim();
  if (text.length < 3) return [];

  const featureList = await fetchPhoton(text, { limit: Math.max(limit * 2, 10), origin });
  const deduped = [];
  const seen = new Set();
  featureList.forEach((feature, index) => {
    const mapped = mapPhotonFeature(feature, index, origin);
    if (!Number.isFinite(mapped.lat) || !Number.isFinite(mapped.lon)) return;
    const key = `${mapped.houseNumber}|${mapped.normRoad}|${mapped.cityName}|${mapped.lat.toFixed(6)}|${mapped.lon.toFixed(6)}`;
    if (seen.has(key)) return;
    seen.add(key);
    deduped.push(mapped);
  });

  return rankResults(deduped, text, origin).slice(0, limit);
}

export async function geocodeAddress(query, { origin = null } = {}) {
  const results = await searchAddresses(query, { limit: 1, origin });
  return results[0] || null;
}

export function haversineMiles(origin, destination) {
  if (!origin || !destination) return 0;
  const toRad = (value) => (Number(value) * Math.PI) / 180;
  const r = 3958.7613;
  const dLat = toRad(destination.lat - origin.lat);
  const dLon = toRad(destination.lon - origin.lon);
  const lat1 = toRad(origin.lat);
  const lat2 = toRad(destination.lat);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return r * c;
}

export async function getRoadMiles(origin, destination) {
  if (!origin || !destination) throw new Error('Missing coordinates');
  const coords = `${origin.lon},${origin.lat};${destination.lon},${destination.lat}`;
  const url = new URL(`/route/v1/driving/${coords}`, OSRM_BASE);
  url.searchParams.set('overview', 'false');
  url.searchParams.set('alternatives', 'false');
  url.searchParams.set('steps', 'false');
  const response = await fetch(url.toString(), { headers: { 'Accept': 'application/json' }, mode: 'cors' });
  if (!response.ok) throw new Error(`Routing failed (${response.status})`);
  const payload = await response.json();
  const meters = payload?.routes?.[0]?.distance;
  if (!Number.isFinite(meters)) throw new Error('No route distance returned');
  return meters / 1609.344;
}

export async function computeDeliveryEstimate(origin, destination) {
  try {
    const oneWayMiles = await getRoadMiles(origin, destination);
    return {
      oneWayMiles,
      roundTripMiles: oneWayMiles * 2,
      source: 'road'
    };
  } catch (error) {
    const fallbackOneWay = haversineMiles(origin, destination);
    return {
      oneWayMiles: fallbackOneWay,
      roundTripMiles: fallbackOneWay * 2,
      source: 'straight-line',
      fallbackReason: error?.message || 'Routing unavailable'
    };
  }
}
